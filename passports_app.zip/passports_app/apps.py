from django.apps import AppConfig


class PassportsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'passports_app'
