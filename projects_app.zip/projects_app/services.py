from __future__ import annotations

from pathlib import Path
from typing import Tuple

from django.db import transaction
from django.db.models import Max

from .models import Project, ProjectRevision


# =========================================================
# FULL_CODE
# =========================================================

def normalize_full_code(value: str) -> str:
    """
    (value) ввод пользователя
    Возвращает "нормализованный" шифр:
    - обрезаем края
    - сжимаем множественные пробелы
    """
    value = (value or "").strip()
    value = " ".join(value.split())
    return value


# =========================================================
# NEEDS_REVIEW ЛОГИКА
# =========================================================

REQUIRED_PROJECT_FIELDS = (
    "full_code",
    "designer",
    "line",
    "design_stage",
    "stage",
    "plot",
    "section",
)


def compute_needs_review(project: Project) -> bool:
    """
    Возвращает True, если проект "требует заполнения":
    - нет полного шифра (full_code)
    - или не заполнены обязательные классификаторы
    """
    for field in REQUIRED_PROJECT_FIELDS:
        val = getattr(project, field)
        if val is None:
            return True
        if isinstance(val, str) and not val.strip():
            return True
    return False


def sync_needs_review(project: Project, *, save: bool = True) -> bool:
    """
    (project) проект
    (save) нужно ли сохранять в БД

    Пересчитывает project.needs_review и, если надо, сохраняет.
    Возвращает итоговое значение.
    """
    new_value = compute_needs_review(project)
    if project.needs_review != new_value:
        project.needs_review = new_value
        if save:
            project.save(update_fields=["needs_review"])
    return project.needs_review


# =========================================================
# РЕВИЗИИ
# =========================================================

def _next_revision_code(project: Project) -> str:
    """
    Возвращает следующий код ревизии "01", "02", ...
    """
    max_rev = (
        ProjectRevision.objects
        .filter(project=project)
        .aggregate(m=Max("revision"))
        .get("m")
    )

    if not max_rev:
        return "01"

    try:
        n = int(max_rev)
    except ValueError:
        # если по какой-то причине ревизия была нечисловой
        n = 0
    return f"{n + 1:02d}"


@transaction.atomic
def attach_revision_to_project(
    *,
    project: Project,
    file_name: str,
    file_path: str,
    sha256: str | None,
) -> Tuple[ProjectRevision, bool]:
    """
    Добавляет ревизию к проекту:
    - все старые is_latest=False
    - новая rev становится is_latest=True
    - дедуп по sha256 внутри проекта

    Возвращает: (revision, created)
      created=False если sha256 уже существует у проекта
    """
    if sha256 and ProjectRevision.objects.filter(project=project, sha256=sha256).exists():
        existing = (
            ProjectRevision.objects
            .filter(project=project, sha256=sha256)
            .order_by("-created_at")
            .first()
        )
        return existing, False

    ProjectRevision.objects.filter(project=project, is_latest=True).update(is_latest=False)

    revision_code = _next_revision_code(project)
    rev = ProjectRevision.objects.create(
        project=project,
        revision=revision_code,
        file_name=file_name,
        file_path=file_path,
        sha256=sha256,
        is_latest=True,
    )

    return rev, True


@transaction.atomic
def set_revision_in_production(*, revision_id: int, value: bool) -> ProjectRevision:
    """
    (revision_id) id ревизии
    (value) True/False

    Просто переключает поле in_production.
    """
    rev = ProjectRevision.objects.select_for_update().get(id=revision_id)
    rev.in_production = value
    rev.save(update_fields=["in_production"])
    return rev


@transaction.atomic
def delete_project_revision(*, revision_id: int) -> None:
    """
    Удаляет ревизию + файл.
    Если удалили актуальную — назначаем актуальной последнюю по created_at.
    Если ревизий не осталось — удаляем проект.
    """
    rev = ProjectRevision.objects.select_related("project").select_for_update().get(id=revision_id)
    project = rev.project

    file_path = Path(rev.file_path)
    rev.delete()

    # удаляем файл (если есть)
    try:
        file_path.unlink(missing_ok=True)
    except Exception:
        pass

    remaining = ProjectRevision.objects.filter(project=project).order_by("-created_at")
    if not remaining.exists():
        project.delete()
        return

    # если актуальной больше нет — назначим
    if not remaining.filter(is_latest=True).exists():
        newest = remaining.first()
        ProjectRevision.objects.filter(project=project, is_latest=True).update(is_latest=False)
        newest.is_latest = True
        newest.save(update_fields=["is_latest"])


@transaction.atomic
def assign_full_code_to_draft(*, draft_project_id: int, full_code_input: str) -> Project:
    """
    Назначает full_code "черновику" (или проекту без шифра).
    Если проект с таким full_code уже существует:
      - переносим ревизии на него
      - удаляем черновик
    """
    full_code = normalize_full_code(full_code_input)

    draft = Project.objects.select_for_update().get(id=draft_project_id)

    existing = Project.objects.filter(full_code=full_code).exclude(id=draft.id).first()
    if existing:
        # переносим ревизии
        ProjectRevision.objects.filter(project=draft).update(project=existing)
        draft.delete()

        # пересчёт needs_review на целевом проекте
        sync_needs_review(existing, save=True)
        return existing

    draft.full_code = full_code
    draft.save(update_fields=["full_code"])

    # после назначения шифра пересчитаем needs_review (скорее всего останется True, пока не заполнены классификаторы)
    sync_needs_review(draft, save=True)
    return draft
